chrome.devtools.panels.create( "WebVR",
    "icon.png",
    "panel.html",
    function(panel) {

      // code invoked on panel creation
    }
);